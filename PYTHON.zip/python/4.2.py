def main():
    number = 1
    max_number = 5

    print("Let's count to 5:")
    while number <= max_number:
        print("Number:", number)
        number += 1

    print("We have reached the maximum number of", max_number)

if __name__ == "__main__":
    main()
