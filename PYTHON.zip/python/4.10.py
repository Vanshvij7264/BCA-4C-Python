def main():
    m = 15 * 13 * 11 * 9 * 7
    print("Product of the series m =", m)

if __name__ == "__main__":
    main()
