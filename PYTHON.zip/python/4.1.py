def main():
    count = 0
    max_count = 5

    print("Let's count to 5:")
    while count < max_count:
        print("Count:", count + 1)
        count += 1

    print("We have reached the maximum count of", max_count)

if __name__ == "__main__":
    main()
