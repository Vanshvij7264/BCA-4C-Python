def main():
    print("Numbers from 10 to 1 in reverse order:")
    for i in range(10, 0, -1):
        print(i)

if __name__ == "__main__":
    main()
